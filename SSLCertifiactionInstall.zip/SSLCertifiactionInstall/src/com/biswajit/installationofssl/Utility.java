package com.biswajit.installationofssl;

public class Utility {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("arg-> 0 :: "+args[0]);
		System.out.println("arg-> 1 :: "+args[1]);

	}

}
